<?php

declare(strict_types=1);

namespace Damoony\Tests\Unit\App;

use Damoony\Core\App\FrontController;
use Damoony\Core\App\PageHandler;
use Damoony\Core\Config;
use Damoony\Core\Container;
use Damoony\Core\Domain\ConfigDomainResolver;
use Damoony\Core\Domain\DomainResolverInterface;
use Damoony\Core\Files\Paths;
use Damoony\Core\Http\Request;
use Damoony\Core\Routing\FileRouter;
use Damoony\Core\Routing\RouterInterface;
use Damoony\Core\Routing\RulesMatcher;
use Damoony\Core\Security\Csrf;
use Damoony\Core\Session\SessionInterface;
use Damoony\Data\Auth\AuthInterface;
use PHPUnit\Framework\TestCase;

final class FrontControllerTest extends TestCase
{
    private string $root;

    protected function setUp(): void
    {
        \Damoony\Core\Error\ErrorPage::bootstrap(
            fallback: 'ru',
            langDir: dirname(__DIR__, 4) . '/lang',
        );

        $this->root = sys_get_temp_dir() . '/damoony_fc_' . bin2hex(random_bytes(4));
        mkdir($this->root, 0o777, true);
    }

    protected function tearDown(): void
    {
        $this->rmrf($this->root);
    }

    private function rmrf(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        foreach (scandir($dir) ?: [] as $i) {
            if ($i === '.' || $i === '..') {
                continue;
            }
            $p = $dir . '/' . $i;
            is_dir($p) ? $this->rmrf($p) : @unlink($p);
        }
        @rmdir($dir);
    }

    private function fc(bool $available): FrontController
    {
        $site = Config::fromArray([
            'language' => 'ru-ru',
            'domains_real' => ['example.ru' => 'example.ru'],
            'domains_available' => ['example.ru' => $available],
            'alliases_real' => ['example.ru' => ['www' => 'www']],
            'domains_namespace' => ['example.ru' => 'example'],
        ]);

        $c = new Container();
        $c->setInstance(Paths::class, new Paths($this->root));
        $c->setInstance('site', $site);

        $session = new class () implements SessionInterface {
            public array $data = [];
            public function start(): void
            {
            }
            public function isStarted(): bool
            {
                return true;
            }
            public function get(string $key, mixed $default = null): mixed
            {
                return $this->data[$key] ?? $default;
            }
            public function set(string $key, mixed $value): void
            {
                $this->data[$key] = $value;
            }
            public function remove(string $key): void
            {
                unset($this->data[$key]);
            }
            public function regenerate(): void
            {
            }
            public function destroy(): void
            {
                $this->data = [];
            }
        };
        $c->setInstance(Csrf::class, new Csrf($session));

        // Мок авторизации
        $c->setInstance(AuthInterface::class, new class () implements AuthInterface {
            public function isAuthenticated(): bool
            {
                return true;
            }
            public function user(): ?array
            {
                return null;
            }
            public function login(string $login, string $password): bool
            {
                return false;
            }
            public function logout(): void
            {
            }
        });

        $c->setInstance(DomainResolverInterface::class, new ConfigDomainResolver($site));
        $c->setInstance(RouterInterface::class, new FileRouter($this->root, new RulesMatcher()));

        $resolver = $c->get(DomainResolverInterface::class);
        assert($resolver instanceof DomainResolverInterface);

        return new FrontController($c, new PageHandler($this->root, $resolver));
    }

    private function req(string $path): Request
    {
        return new Request('GET', $path, headers: ['host' => 'example.ru']);
    }

    public function testUnavailableDomainReturns503(): void
    {
        self::assertSame(503, $this->fc(false)->handle($this->req('/'))->status);
    }

    public function testUnknownRouteReturns404(): void
    {
        self::assertSame(404, $this->fc(true)->handle($this->req('/nope'))->status);
    }

    public function testMatchedRouteRendersPage(): void
    {
        $base = $this->root . '/app/example.ru/www/algoritm';
        mkdir($base . '/fc_home', 0o777, true);
        file_put_contents($base . '/algoritm.rules.json', json_encode(['available' => ['fc_home'], 'auth' => false, 'search' => true, 'default' => false]));
        file_put_contents($base . '/fc_home/algoritm_fc_home.rules.json', json_encode(['available' => [], 'auth' => false, 'search' => true, 'default' => false]));
        file_put_contents($base . '/fc_home/algoritm_fc_home.php', <<<'PHP'
            <?php
            namespace example\www;
            use Damoony\UI\Algoritm\Page;
            use Damoony\Core\Http\Response;
            use Damoony\UI\Builder;
            use Damoony\UI\Node;
            final class algoritm_fc_home extends Page {
                protected function content(): Node|Response|null {
                    return Builder::div('page')->content('home');
                }
            }
            PHP);

        $r = $this->fc(true)->handle($this->req('/fc_home'));
        self::assertSame(200, $r->status);
        self::assertStringContainsString('<div class="page">home</div>', $r->body);
    }
}
