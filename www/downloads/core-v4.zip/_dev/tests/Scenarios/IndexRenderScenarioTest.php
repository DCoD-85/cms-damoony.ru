<?php

declare(strict_types=1);

namespace Damoony\Tests\Scenarios;

use Damoony\Core\App\FrontController;
use Damoony\Core\App\PageHandler;
use Damoony\Core\Config;
use Damoony\Core\Container;
use Damoony\Core\Domain\ConfigDomainResolver;
use Damoony\Core\Domain\DomainResolverInterface;
use Damoony\Core\Files\Paths;
use Damoony\Core\Http\Request;
use Damoony\Core\Routing\FileRouter;
use Damoony\Core\Routing\RouterInterface;
use Damoony\Core\Routing\RulesMatcher;
use PHPUnit\Framework\TestCase;

final class IndexRenderScenarioTest extends TestCase
{
    private string $root;

    protected function setUp(): void
    {
        \Damoony\Core\Error\ErrorPage::bootstrap(
            fallback: 'ru',
            langDir: dirname(__DIR__, 3) . '/lang',
        );

        $this->root = sys_get_temp_dir() . '/damoony_s11_' . bin2hex(random_bytes(4));
        $dir = $this->root . '/app/damoony.test/www/algoritm';
        mkdir($dir, 0o777, true);
        file_put_contents($dir . '/algoritm.rules.json', json_encode(['available' => ['']]));
        file_put_contents($dir . '/algoritm.php', <<<'PHP'
            <?php
            namespace damoony_test\www;
            use Damoony\Demo\Page\HomePage;
            final class algoritm extends HomePage {}
            PHP);

        $globalDir = $this->root . '/app/damoony.test/.blocksglobal';
        mkdir($globalDir . '/hello', 0o777, true);
        mkdir($globalDir . '/footer', 0o777, true);

        file_put_contents($globalDir . '/hello/hello.php', <<<'PHP'
            <?php
            namespace damoony_test;
            use Damoony\UI\Region\RegionContext;
            use Damoony\UI\Region\RegionInterface;
            use Damoony\UI\Builder;
            use Damoony\UI\Node;
            final class blocksglobal_hello implements RegionInterface {
                public function name(): string { return 'hello'; }
                public function enabled(): bool { return true; }
                public function render(RegionContext $context): Node {
                    return Builder::div('hello')->content('Hello from test');
                }
            }
            PHP);

        file_put_contents($globalDir . '/footer/footer.php', <<<'PHP'
            <?php
            namespace damoony_test;
            use Damoony\UI\Region\RegionContext;
            use Damoony\UI\Region\RegionInterface;
            use Damoony\UI\Builder;
            use Damoony\UI\Node;
            final class blocksglobal_footer implements RegionInterface {
                public function name(): string { return 'footer'; }
                public function enabled(): bool { return true; }
                public function render(RegionContext $context): Node {
                    return Builder::div('footer')->content('Footer from test');
                }
            }
            PHP);

        $schemeDir = $this->root . '/app/damoony.test/.schemesglobal';
        mkdir($schemeDir, 0o777, true);
        file_put_contents($schemeDir . '/www.php', <<<'PHP'
            <?php
            return [
                'tag' => 'div',
                'class' => 'layout',
                'children' => [
                    ['tag' => 'section', 'slot' => 'hello'],
                    ['tag' => 'footer', 'slot' => 'footer'],
                ],
            ];
            PHP);
    }

    protected function tearDown(): void
    {
        $this->rmrf($this->root);
    }

    private function rmrf(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        foreach (scandir($dir) ?: [] as $i) {
            if ($i === '.' || $i === '..') {
                continue;
            }
            $p = $dir . '/' . $i;
            is_dir($p) ? $this->rmrf($p) : @unlink($p);
        }
        @rmdir($dir);
    }

    private function fc(): FrontController
    {
        $site = Config::fromArray([
            'language' => 'ru', // ИЗМЕНЕНО: ru вместо ru-ru
            'domains_real' => ['damoony.test' => 'damoony.test'],
            'domains_available' => ['damoony.test' => true],
            'alliases_real' => ['damoony.test' => ['www' => 'www']],
            'domains_namespace' => ['damoony.test' => 'damoony_test'],
        ]);
        $c = new Container();
        $c->setInstance(Paths::class, new Paths($this->root));
        $c->setInstance('site', $site);

        $session = new class () implements \Damoony\Core\Session\SessionInterface {
            public array $data = [];
            public function start(): void
            {
            }
            public function isStarted(): bool
            {
                return true;
            }
            public function get(string $key, mixed $default = null): mixed
            {
                return $this->data[$key] ?? $default;
            }
            public function set(string $key, mixed $value): void
            {
                $this->data[$key] = $value;
            }
            public function remove(string $key): void
            {
                unset($this->data[$key]);
            }
            public function regenerate(): void
            {
            }
            public function destroy(): void
            {
                $this->data = [];
            }
        };
        $c->setInstance(\Damoony\Core\Security\Csrf::class, new \Damoony\Core\Security\Csrf($session));

        $c->setInstance(\Damoony\Data\Auth\AuthInterface::class, new class () implements \Damoony\Data\Auth\AuthInterface {
            public function isAuthenticated(): bool
            {
                return true;
            }
            public function user(): ?array
            {
                return null;
            }
            public function login(string $login, string $password): bool
            {
                return false;
            }
            public function logout(): void
            {
            }
        });

        $c->setInstance(DomainResolverInterface::class, new ConfigDomainResolver($site));
        $c->setInstance(RouterInterface::class, new FileRouter($this->root, new RulesMatcher()));

        $resolver = $c->get(DomainResolverInterface::class);
        assert($resolver instanceof DomainResolverInterface);

        return new FrontController($c, new PageHandler($this->root, $resolver));
    }

    public function testIndexRendersRegionsViaScheme(): void
    {
        $r = $this->fc()->handle(new Request('GET', '/', headers: ['host' => 'damoony.test']));

        self::assertSame(200, $r->status);
        self::assertStringContainsString('<!DOCTYPE html>', $r->body);
        self::assertStringContainsString('lang="ru"', $r->body); // ИЗМЕНЕНО: lang="ru" вместо lang="ru-ru"
        self::assertStringContainsString('<div class="hello">Hello from test</div>', $r->body);
        self::assertStringContainsString('<div class="footer">Footer from test</div>', $r->body);
    }
}
