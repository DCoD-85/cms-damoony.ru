<?php

declare(strict_types=1);

namespace Damoony\Core\App;

use Damoony\Core\Application;
use Damoony\Core\Config;
use Damoony\Core\Container;
use Damoony\Core\Domain\ConfigDomainResolver;
use Damoony\Core\Domain\DomainResolverInterface;
use Damoony\Core\Env;
use Damoony\Core\Error\ErrorPage;
use Damoony\Core\ErrorHandler;
use Damoony\Core\Files\Paths;
use Damoony\Core\Logger;
use Damoony\Core\Routing\FileRouter;
use Damoony\Core\Routing\RouterInterface;
use Damoony\Core\Routing\RulesMatcher;
use Damoony\Core\Security\Csrf;
use Damoony\Core\Session\NativeSession;
use Damoony\Data\Auth\AuthInterface;
use Damoony\Data\Auth\DbAuth;
use Damoony\Data\Db\Connection;

final class AppFactory
{
    public static function create(string $root, ?Env $env = null): Application
    {
        $env ??= Env::fromServer();
        $configFile = $root . '/config/engine.config';
        $siteFile = $root . '/config/site.config';

        $config = is_file($configFile) ? Config::fromFile($configFile) : Config::fromArray([]);
        $site = is_file($siteFile) ? Config::fromFile($siteFile) : Config::fromArray([]);

        $container = new Container();
        $logger = new Logger(null, $env);
        $errorHandler = new ErrorHandler($logger, $env);

        $container->setInstance(Env::class, $env);
        $container->setInstance(Config::class, $config);
        $container->setInstance('site', $site);

        $adminConfigFile = $root . '/config/admin.config';
        $adminConfig = is_file($adminConfigFile) ? Config::fromFile($adminConfigFile) : Config::fromArray([]);
        $container->setInstance('admin_config', $adminConfig);

        ErrorPage::bootstrap(
            fallback: (string) $adminConfig->getByKey(['default_lang'], ''),
            langDir: $root . '/lang',
        );
        $container->setInstance('logger', $logger);
        $container->setInstance('errorHandler', $errorHandler);
        $container->setInstance(Paths::class, new Paths($root));

        // БД (из engine.config)
        $dbConfig = $config->getByKey(['db'], []);
        if (!is_array($dbConfig) || $dbConfig === []) {
            $dbConfig = [
                'driver' => 'sqlite',
                'path' => $root . '/var/damoony.db',
            ];
        } else {
            if (($dbConfig['driver'] ?? '') === 'sqlite' && isset($dbConfig['path'])) {
                $path = (string) $dbConfig['path'];
                if (!str_starts_with($path, '/') && !preg_match('/^[a-zA-Z]:[\\\\\/]/', $path)) {
                    $dbConfig['path'] = $root . '/' . ltrim($path, '/\\');
                }
            }
        }
        $db = new Connection($dbConfig);
        $container->setInstance(Connection::class, $db);

        // Сессия, авторизация, CSRF
        $session = new NativeSession('SITE_SESSID', ($_SERVER['HTTPS'] ?? '') === 'on');
        $session->start();
        $container->setInstance(\Damoony\Core\Session\SessionInterface::class, $session);
        $container->setInstance(AuthInterface::class, new DbAuth($db, $session));
        $container->setInstance(Csrf::class, new Csrf($session));

        $container->set(
            DomainResolverInterface::class,
            fn (): DomainResolverInterface => new ConfigDomainResolver($site, $container->get(Paths::class)),
        );

        $container->set(
            RouterInterface::class,
            fn () => new FileRouter($root, new RulesMatcher()),
        );

        $container->set(
            PageHandlerInterface::class,
            function (Container $c) use ($root): PageHandlerInterface {
                $resolver = $c->get(DomainResolverInterface::class);
                if (!$resolver instanceof DomainResolverInterface) {
                    throw new \RuntimeException('DomainResolverInterface expected');
                }
                return new PageHandler($root, $resolver);
            },
        );

        $container->set(
            Application::class,
            fn (Container $c) => new Application($c, $env, $config, $logger, $errorHandler),
        );

        $app = $container->get(Application::class);
        if (!$app instanceof Application) {
            throw new \RuntimeException('Application expected');
        }
        $app->boot();

        return $app;
    }
}
